export { GitLabAdapter } from './adapter';
