export { GitHubAdapter } from './adapter';
